<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Producto_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->farmacia_db = $this->load->database('user_db', TRUE); // Cargar la base de datos de productos
    }

    public function get_productos() {
        $query = $this->farmacia_db->get('productos'); // Usar la conexión farmacia_db
        return $query->result();
    }
}


