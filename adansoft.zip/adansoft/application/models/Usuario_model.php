<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->user_usuarios = $this->load->database('user_usuarios', TRUE); // Cargar la base de datos de usuarios
    }

    public function register($data) {
        return $this->user_usuarios->insert('usuarios', $data);
    }


    public function login($username, $password) {
        $this->user_usuarios->where('usuario', $username);
        $query = $this->user_usuarios->get('usuarios');

        if ($query->num_rows() == 1) {
            $user = $query->row();
            if (password_verify($password, $user->password)) {
                return $user;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    public function check_duplicate_dni($dni) {
        $this->user_usuarios->where('documento_numero', $dni);
        $query = $this->user_usuarios->get('usuarios');
        return ($query->num_rows() > 0);
    }

    public function check_duplicate_celular($celular) {
        $this->user_usuarios->where('celular', $celular);
        $query = $this->user_usuarios->get('usuarios');
        return ($query->num_rows() > 0);
    }
    
    
    public function get_usuario_por_nombre($username) {
        $this->user_usuarios->where('usuario', $username);
        $query = $this->user_usuarios->get('usuarios');
        return $query->row();
    }
    
    public function actualizar_usuario($id, $data) {
        $this->user_usuarios->where('id', $id);
        return $this->user_usuarios->update('usuarios', $data);
    }


    
}




