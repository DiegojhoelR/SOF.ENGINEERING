<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Farmacia Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            padding-top: 60px;
            background-color: #f8f9fa;
        }
        .navbar {
            margin-bottom: 20px;
        }
        .card {
            height: 100%;
            display: flex;
            flex-direction: column;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .card-img-top {
            max-height: 200px;
            max-width: 100%;
            width: auto;
            height: auto;
            display: block;
            margin: 0 auto;
            border-bottom: 1px solid #ddd;
        }
        .card-body {
            flex: 1;
            padding: 20px;
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .footer {
            background-color: #343a40;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        .offcanvas-body {
            padding: 20px;
        }
        .offcanvas-header {
            background-color: #007bff;
            color: white;
        }
        .btn-primary, .btn-danger, .btn-warning, .btn-success {
            width: 100%;
            margin-bottom: 10px;
        }
        .table th, .table td {
            vertical-align: middle;
            text-align: center;
        }
        .product-img {
            height: 50px;
            object-fit: cover;
            margin-right: 10px;
        }
        .cart-item {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .cart-item img {
            margin-right: 10px;
        }
        .cart-item-details {
            flex: 1;
        }
        .cart-item-actions button {
            border: none;
            background: none;
            color: #007bff;
            cursor: pointer;
        }
        .cart-item-actions button:hover {
            color: #0056b3;
        }
        .offcanvas-footer {
            padding-top: 20px;
            border-top: 1px solid #e9ecef;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar-brand {
            font-size: 1.5rem;
        }
        .offcanvas-title {
            font-size: 1.5rem;
        }
        .offcanvas-cart-title {
            font-size: 1.5rem;
        }
        .offcanvas-cart-item {
            font-size: 1rem;
        }
        .offcanvas-cart-total {
            font-size: 1.25rem;
            font-weight: bold;
            margin-top: 20px;
        }
        .offcanvas-cart-actions .btn {
            font-size: 1.5rem;
        }
        .navbar-nav .nav-item .nav-link {
            font-size: 1rem;
            font-weight: 500;
            color: #555;
            transition: color 0.3s;
        }
        .navbar-nav .nav-item .nav-link:hover {
            color: #007bff;
        }
        .search-bar {
            flex-grow: 1;
        }
        .search-bar input[type="text"] {
            width: 100%;
            padding: 0.5rem;
            border-radius: 20px;
            border: 1px solid #ddd;
            transition: border-color 0.3s;
        }
        .search-bar input[type="text"]:focus {
            border-color: #007bff;
        }
        .nav-categories {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin-top: 20px;
            padding: 10px 0;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .nav-categories a {
            color: #555;
            font-weight: 500;
            transition: color 0.3s;
            padding: 0.5rem 1rem;
            text-decoration: none;
        }
        .nav-categories a:hover {
            color: #007bff;
        }
        .cart-summary {
            margin-top: 20px;
        }
        .cart-summary h3 {
            margin-bottom: 10px;
        }
        .cart-summary .btn {
            width: 48%;
        }
        .cart-summary .btn-vaciar {
            background-color: #ffc107;
            color: #fff;
        }
        .cart-summary .btn-proceder {
            background-color: #28a745;
            color: #fff;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="https://adan.ed.pe/assets/imagenes/logo_oficial.png" alt="Farmacia Online" style="height: 60px;">
            </a>
            <div class="collapse navbar-collapse">
                <form class="search-bar d-flex mx-auto" method="get" action="<?php ?>" style="margin: 0 auto;">
                    <input class="form-control me-2" type="search" placeholder="¿Qué estás buscando?" aria-label="Search" name="buscar">
                    <button class="btn btn-outline-success" type="submit">Buscar</button>
                </form>
                <ul class="navbar-nav ms-auto">
                    <?php if ($logged_in): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo site_url('welcome/perfil'); ?>">Perfil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo site_url('welcome/logout'); ?>">Cerrar Sesión</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo site_url('welcome/index'); ?>">Login</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-bs-toggle="offcanvas" data-bs-target="#offcanvasCart" aria-controls="offcanvasCart">
                            Carrito <span class="badge bg-secondary"><?php echo count($cart); ?></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <!-- Mostrar mensajes de error -->
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('error'); ?>
            </div>
        <?php endif; ?>
        
        <div class="nav-categories">
            <?php foreach ($categorias as $cat): ?>
                <a href="<?php echo site_url('welcome/home?categoria=' . $cat->categoria); ?>" class="<?php echo ($selected_categoria == $cat->categoria) ? 'active' : ''; ?>">
                    <?php echo ucfirst($cat->categoria); ?>
                </a>
            <?php endforeach; ?>
        </div>
        
        <div class="row gy-4 mt-3">
            <?php foreach ($productos as $producto): ?>
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="<?php echo $producto->imagen; ?>" class="card-img-top" alt="<?php echo $producto->nombre; ?>">
                    <div class="card-body d-flex flex-column">
                        <div>
                            <h5 class="card-title"><?php echo $producto->nombre; ?></h5>
                            <p class="card-text"><?php echo $producto->descripcion; ?></p>
                            <p class="card-text"><strong>Precio: S/<?php echo number_format($producto->precio, 2); ?></strong></p>
                        </div>
                        <div class="quantity-controls mt-auto">
                            <button class="btn btn-link btn-decrease" data-id="<?php echo $producto->id; ?>"><i class="fas fa-minus"></i></button>
                            <span class="quantity">1</span>
                            <button class="btn btn-link btn-increase" data-id="<?php echo $producto->id; ?>"><i class="fas fa-plus"></i></button>
                            <button class="btn btn-primary btn-add-to-cart" data-id="<?php echo $producto->id; ?>">Añadir al carrito</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    

    <!-- Offcanvas para el carrito -->
    <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasCart" aria-labelledby="offcanvasCartLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title offcanvas-cart-title" id="offcanvasCartLabel">Carrito de Compras</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body offcanvas-cart-item">
            <?php if (!empty($cart)): ?>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Precio</th>
                            <th>Cantidad</th>
                            <th>Total</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart as $item): ?>
                            <tr>
                                <td class="cart-item">
                                    <?php if (isset($item['image'])): ?>
                                        <img src="<?php echo $item['image']; ?>" class="product-img" alt="<?php echo $item['name']; ?>">
                                    <?php endif; ?>
                                    <span><?php echo $item['name']; ?></span>
                                </td>
                                <td>S/<?php echo number_format($item['price'], 2); ?></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td>S/<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                <td>
                                    <a href="<?php echo site_url('welcome/remove_from_cart/' . $item['id']); ?>" class="btn btn-danger">Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="cart-summary">
                    <h3>Total a Pagar: S/<?php echo number_format($total, 2); ?></h3>
                    <div class="d-flex justify-content-between">
                        <a href="<?php echo site_url('welcome/clear_cart'); ?>" class="btn btn-vaciar">Vaciar Carrito</a>
                        <button class="btn btn-success" onclick="window.location.href='<?php echo site_url('welcome/checkout'); ?>'">Proceder al Pago</button>
                    </div>
                </div>
            <?php else: ?>
                <p>No hay productos en el carrito.</p>
            <?php endif; ?>
        </div>
    </div>

    <footer class="footer mt-auto py-3">
        <div class="container">
            <span class="text-muted">© 2024 Farmacia Online. Todos los derechos reservados.</span>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const decreaseButtons = document.querySelectorAll('.btn-decrease');
            const increaseButtons = document.querySelectorAll('.btn-increase');
            const addToCartButtons = document.querySelectorAll('.btn-add-to-cart');

            decreaseButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.dataset.id;
                    const quantityElement = this.nextElementSibling;
                    let quantity = parseInt(quantityElement.textContent);
                    if (quantity > 1) {
                        quantity--;
                        quantityElement.textContent = quantity;
                    }
                });
            });

            increaseButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.dataset.id;
                    const quantityElement = this.previousElementSibling;
                    let quantity = parseInt(quantityElement.textContent);
                    quantity++;
                    quantityElement.textContent = quantity;
                });
            });

            addToCartButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.dataset.id;
                    const quantityElement = this.previousElementSibling.previousElementSibling;
                    const quantity = parseInt(quantityElement.textContent);

                    // Redirigir para añadir al carrito con la cantidad especificada
                    window.location.href = '<?php echo site_url('welcome/add_to_cart'); ?>/' + productId + '/' + quantity;
                });
            });
        });
    </script>
</body>
</html>
