<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Consultas extends CI_Model {
    
    public function login($username , $password){
        
        $query = $this->db->get_where("usuario", array("usuario" => $username, "password"=> $password));
        
        return $query->row();
    }
}