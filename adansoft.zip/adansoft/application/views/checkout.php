<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout - Farmacia Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            padding-top: 60px;
            background-color: #f8f9fa;
        }
        .navbar {
            margin-bottom: 20px;
        }
        .container {
            max-width: 1200px;
            margin-top: 20px;
        }
        .card {
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .card h3 {
            margin-bottom: 20px;
        }
        .table th, .table td {
            vertical-align: middle;
            text-align: center;
        }
        .total-cart {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">
                <img src="https://adan.ed.pe/assets/imagenes/logo_oficial.png" alt="Farmacia Online" style="height: 60px;">
            </a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo site_url('welcome/home'); ?>">Inicio</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <h3>Información de contacto</h3>
                    <form>
                        <div class="mb-3">
                            <label for="nombre" class="form-label">Nombre:</label>
                            <input type="text" class="form-control" id="nombre" name="nombre" required>
                        </div>
                        <div class="mb-3">
                            <label for="apellidos" class="form-label">Apellidos:</label>
                            <input type="text" class="form-control" id="apellidos" name="apellidos" required>
                        </div>
                        <div class="mb-3">
                            <label for="documento_tipo" class="form-label">Documento:</label>
                            <select class="form-select" id="documento_tipo" name="documento_tipo" required>
                                <option value="DNI">DNI</option>
                                <option value="Pasaporte">Pasaporte</option>
                                <option value="Carnet de Extranjería">Carnet de Extranjería</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="documento_numero" class="form-label">Número de documento:</label>
                            <input type="text" class="form-control" id="documento_numero" name="documento_numero" required>
                        </div>
                        <div class="mb-3">
                            <label for="correo_electronico" class="form-label">Correo Electrónico:</label>
                            <input type="email" class="form-control" id="correo_electronico" name="correo_electronico" required>
                        </div>
                        <div class="mb-3">
                            <label for="telefono" class="form-label">Teléfono:</label>
                            <input type="text" class="form-control" id="telefono" name="telefono" required>
                        </div>
                        <h3>Dirección de Envío</h3>
                        <div class="mb-3">
                            <label for="pais" class="form-label">País:</label>
                            <select class="form-select" id="pais" name="pais" required>
                                <option value="Perú">Perú</option>
                                <!-- Agrega otros países según sea necesario -->
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="departamento" class="form-label">Departamento:</label>
                            <select class="form-select" id="departamento" name="departamento" required>
                                <option value="">Seleccione</option>
                                <!-- Agrega opciones de departamentos -->
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="provincia" class="form-label">Provincia:</label>
                            <select class="form-select" id="provincia" name="provincia" required>
                                <option value="">Seleccione</option>
                                <!-- Agrega opciones de provincias -->
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="distrito" class="form-label">Distrito:</label>
                            <select class="form-select" id="distrito" name="distrito" required>
                                <option value="">Seleccione</option>
                                <!-- Agrega opciones de distritos -->
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="direccion" class="form-label">Dirección:</label>
                            <input type="text" class="form-control" id="direccion" name="direccion" required>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <h3>Resumen del Pedido</h3>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Precio</th>
                                <th>Cantidad</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cart as $item): ?>
                                <tr>
                                    <td><?php echo $item['name']; ?></td>
                                    <td>S/<?php echo number_format($item['price'], 2); ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td>S/<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="total-cart">
                        <h4>Total a Pagar: S/<?php echo number_format($total, 2); ?></h4>
                        <div class="mb-3">
                            <label for="cupon" class="form-label">Cupón:</label>
                            <input type="text" class="form-control" id="cupon" name="cupon">
                            <button class="btn btn-primary mt-2">Aplicar</button>
                        </div>
                        <div class="mb-3">
                            <label for="observaciones" class="form-label">Observaciones:</label>
                            <textarea class="form-control" id="observaciones" name="observaciones"></textarea>
                        </div>
                        <button class="btn btn-success w-100">Finalizar Compra</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer mt-auto py-3">
        <div class="container">
            <span class="text-muted">© 2024 Farmacia Online. Todos los derechos reservados.</span>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
