<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Consultas extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database(); // Cargar la base de datos en el constructor
    }

    public function register($username, $password) {
        $data = array(
            'usuario' => $username,
            'password' => $password, // Hasheando la contraseña antes de guardarla
        );
        return $this->db->insert('usuarios', $data);
    }

    public function login($username, $password) {
        // Hashear la contraseña ingresada
        $hashed_password = $password;
        $this->db->where('usuario', $username);
        $this->db->where('password', $hashed_password);
        $query = $this->db->get('usuarios'); // Asegúrate de que el nombre de la tabla es correcto
        
        if ($query->num_rows() == 1) {
            return $query->row(); // Devuelve un objeto con la información del usuario
        } else {
            return false;
        }
    }
}
