<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Farmacia Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            padding-top: 60px;
        }
        .navbar {
            margin-bottom: 20px;
        }
        .card-img-top {
            height: 200px;
            object-fit: cover;
        }
        .footer {
            background-color: #f8f9fa;
            padding: 20px 0;
            text-align: center;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Farmacia Online</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo site_url('welcome/index'); ?>">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Carrito <span class="badge bg-secondary">0</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container mt-5">
        <div class="jumbotron">
            <h1 class="display-4">Bienvenidos a Nuestra Farmacia Online</h1>
            <p class="lead">Encuentra los mejores medicamentos a los mejores precios.</p>
            <hr class="my-4">
            <p>Compra de manera fácil y rápida.</p>
        </div>
        
        <div class="row">
            <?php foreach ($productos as $producto): ?>
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="<?php echo $producto->imagen; ?>" class="card-img-top" alt="<?php echo $producto->nombre; ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $producto->nombre; ?></h5>
                        <p class="card-text"><?php echo $producto->descripcion; ?></p>
                        <p class="card-text"><strong>Precio: $<?php echo number_format($producto->precio, 2); ?></strong></p>
                        <a href="#" class="btn btn-primary">Comprar</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <footer class="footer mt-auto py-3">
        <div class="container">
            <span class="text-muted">© 2024 Farmacia Online. Todos los derechos reservados.</span>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>

