<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->user_usuarios = $this->load->database('user_usuarios', TRUE); // Cargar la base de datos de usuarios
    }

    public function register($username, $password) {
        $data = array(
            'usuario' => $username,
            'password' => ($password) // Hasheando la contraseña antes de guardarla
        );
        return $this->user_usuarios->insert('usuarios', $data); // Usar la conexión default
    }

    public function login($username, $password) {
        $hashed_password = ($password);

        // Mensajes de depuraci��n
        log_message('debug', 'Usuario_model::login - username: ' . $username);
        log_message('debug', 'Usuario_model::login - hashed_password: ' . $hashed_password);

        $this->user_usuarios->where('usuario', $username);
        $this->user_usuarios->where('password', $hashed_password);
        $query = $this->user_usuarios->get('usuarios');

        // Mensaje de depuraci��n para la consulta
        log_message('debug', 'Usuario_model::login - query: ' . $this->user_usuarios->last_query());

        if ($query->num_rows() == 1) {
            log_message('debug', 'Usuario_model::login - usuario encontrado');
            return $query->row();
        } else {
            log_message('debug', 'Usuario_model::login - usuario no encontrado');
            return false;
        }
    }
}




