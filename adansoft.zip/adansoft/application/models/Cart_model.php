<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart_model extends CI_Model {

    private $user_db;

    public function __construct() {
        parent::__construct();
        // Cargar la base de datos user_db
        $this->user_db = $this->load->database('user_db', TRUE);
        $this->load->library('session');
        $this->load->model('Producto_model'); // Cargar el modelo de productos
    }

    public function add_to_cart($product_id, $quantity = 1) {
         $stock = $this->Producto_model->get_stock($product_id);
        $product = $this->user_db->get_where('productos', array('id' => $product_id))->row();
        if ($stock < $quantity) {
            return false; // No hay suficiente stock
        }

        $product = $this->user_db->get_where('productos', array('id' => $product_id))->row();
        if (!$product) {
            return false;
        }
        if (!$product) {
            return false;
        }

        $cart = $this->session->userdata('cart') ?: array();

        if (isset($cart[$product_id])) {
            $cart[$product_id]['quantity'] += $quantity;
        } else {
            $cart[$product_id] = array(
                'id' => $product_id,
                'name' => $product->nombre,
                'price' => $product->precio,
                'quantity' => $quantity,
                'image' => $product->imagen
            );
        }

        $this->session->set_userdata('cart', $cart);
        $this->Producto_model->update_stock($product_id, $quantity); // Actualizar el stock

        return true;
    }

    public function get_cart() {
        return $this->session->userdata('cart') ?: array();
    }

    public function get_total() {
        $cart = $this->get_cart();
        $total = 0;

        foreach ($cart as $item) {
            $total += $item['price'] * $item['quantity'];
        }

        return $total;
    }

    public function remove_from_cart($product_id) {
        $cart = $this->session->userdata('cart') ?: array();

       if (isset($cart[$product_id])) {
            $quantity = $cart[$product_id]['quantity'];
            unset($cart[$product_id]);
            $this->Producto_model->update_stock($product_id, -$quantity); // Devolver el stock
        }


        $this->session->set_userdata('cart', $cart);
    }

    public function clear_cart() {
        $this->session->unset_userdata('cart');
        foreach ($cart as $product_id => $item) {
            $this->Producto_model->update_stock($product_id, -$item['quantity']); // Devolver el stock
        }
        $this->session->unset_userdata('cart');
    }
}