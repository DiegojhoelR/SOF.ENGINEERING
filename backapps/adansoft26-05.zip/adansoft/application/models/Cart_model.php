<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart_model extends CI_Model {

    private $user_db;

    public function __construct() {
        parent::__construct();
        // Cargar la base de datos user_db
        $this->user_db = $this->load->database('user_db', TRUE);
        $this->load->library('session');
    }

    public function add_to_cart($product_id, $quantity = 1) {
        // Obtener el producto desde la base de datos user_db
        $product = $this->user_db->get_where('productos', array('id' => $product_id))->row();
        if (!$product) {
            return false;
        }

        // Crear o actualizar el carrito en la sesión
        $cart = $this->session->userdata('cart') ?: array();

        if (isset($cart[$product_id])) {
            // Si el producto ya está en el carrito, actualiza la cantidad
            $cart[$product_id]['quantity'] += $quantity;
        } else {
            // Añadir nuevo producto al carrito
            $cart[$product_id] = array(
                'id' => $product_id,
                'name' => $product->nombre,
                'price' => $product->precio,
                'quantity' => $quantity
            );
        }

        $this->session->set_userdata('cart', $cart);
        return true;
    }

    public function get_cart() {
        return $this->session->userdata('cart') ?: array();
    }

    public function get_total() {
        $cart = $this->get_cart();
        $total = 0;

        foreach ($cart as $item) {
            $total += $item['price'] * $item['quantity'];
        }

        return $total;
    }

    public function remove_from_cart($product_id) {
        $cart = $this->session->userdata('cart') ?: array();

        if (isset($cart[$product_id])) {
            unset($cart[$product_id]);
        }

        $this->session->set_userdata('cart', $cart);
    }

    public function clear_cart() {
        $this->session->unset_userdata('cart');
    }
}
