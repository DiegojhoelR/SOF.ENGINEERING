<?
echo"hola mundo desde mi servidor";
?>