<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library(array('form_validation', 'session'));
        $this->load->model('Producto_model');
        $this->load->model('Usuario_model'); // Asegúrate de cargar el modelo de usuarios
    }

    public function index() {
        $this->load->view('welcome_message');
    }

        public function home() {
        $data['productos'] = $this->Producto_model->get_productos();
        $this->load->view('home', $data);
    }


    public function verificaingreso() {
        $username = $this->input->post("user");
        $password = $this->input->post("pass");
        $resultado = $this->Consultas->login($username, $password);
        if ($resultado) {
            // Set session data
            $this->session->set_userdata('username', $username);
            $this->session->set_userdata('logged_in', TRUE);

            // Load user panel view
            $this->load->view('panel1');
        } else {
            echo "no puedes ingresar";
        }
    }

    public function panel() {
        // Check if user is logged in
        if (!$this->session->userdata('logged_in')) {
            redirect('welcome/index');
        }
        $this->load->view('panel1');
    }

    public function logout() {
        // Destroy session data
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('logged_in');
        $this->session->sess_destroy();
        redirect('welcome/index');
    }

    public function show_register() {
        $this->load->view('register');
    }
    

    public function register() {
    // Set form validation rules
    $this->form_validation->set_rules('username', 'Username', 'required');
    $this->form_validation->set_rules('password', 'Password', 'required');

    if ($this->form_validation->run() == FALSE) {
        // Validation failed
        $this->load->view('register');
    } else {
        // Get input values
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        // Register the user
        if ($this->Consultas->register($username, $password)) {
            echo "User registered successfully";
        } else {
            echo "Failed to register user";
        }
    }
}

}
