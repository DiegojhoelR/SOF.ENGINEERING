<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library(array('form_validation', 'session'));
        $this->load->model('Producto_model');
        $this->load->model('Usuario_model');
        $this->load->model('Cart_model');
    }

    public function index() {
        $this->load->view('welcome_message');
    }

    public function home() {
        $categoria = $this->input->get('categoria');
        $keyword = $this->input->get('buscar');
    
        $data['productos'] = $this->Producto_model->get_productos($categoria, $keyword);
        $data['cart'] = $this->Cart_model->get_cart();
        $data['total'] = $this->Cart_model->get_total();
        $data['categorias'] = $this->Producto_model->get_categorias();
        $data['selected_categoria'] = $categoria;
        $data['search_query'] = $keyword;
        $data['cart_count'] = count($data['cart']); // Contar productos en el carrito

        // A単adir datos de usuario
        $data['username'] = $this->session->userdata('username');
        $data['logged_in'] = $this->session->userdata('logged_in');

        $this->load->view('home', $data);
    }

    public function add_to_cart($product_id, $quantity = 1)  {
        if ($this->Cart_model->add_to_cart($product_id, $quantity)) {
            redirect('welcome/home');
        } else {
            $this->session->set_flashdata('error', 'No hay suficiente stock disponible.');
            redirect('welcome/home');
        }
    }

    public function remove_from_cart($product_id) {
        $this->Cart_model->remove_from_cart($product_id);
        redirect('welcome/home');
    }

    public function clear_cart() {
        $this->Cart_model->clear_cart();
        redirect('welcome/home');
    }

    public function verificaingreso() {
        $username = $this->input->post("user");
        $password = $this->input->post("pass");

        $resultado = $this->Usuario_model->login($username, $password);
        if ($resultado) {
            $this->session->set_userdata('username', $username);
            $this->session->set_userdata('logged_in', TRUE);
            redirect('welcome/home');
        } else {
            $this->session->set_flashdata('error', 'Correo o contraseña incorrectos');
            redirect('welcome/index');
        }
    }


    public function panel() {
        if (!$this->session->userdata('logged_in')) {
            redirect('welcome/index');
        }
        $this->load->view('panel1');
    }

    public function logout() {
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('logged_in');
        $this->session->sess_destroy();
        redirect('welcome/index');
    }

    public function show_register() {
        $this->load->view('register');
    }

    public function register() {
        $this->form_validation->set_rules('documento_tipo', 'Tipo de Documento', 'required');
        $this->form_validation->set_rules('documento_numero', 'Número de Documento', 'required|callback_check_duplicate_dni');
        $this->form_validation->set_rules('nombres', 'Nombres', 'required');
        $this->form_validation->set_rules('apellidos', 'Apellidos', 'required');
        $this->form_validation->set_rules('correo_electronico', 'Correo Electrónico', 'required|valid_email');
        $this->form_validation->set_rules('celular', 'Celular', 'required|callback_check_duplicate_celular');
        $this->form_validation->set_rules('password', 'Contraseña', 'required');
        $this->form_validation->set_rules('conf_password', 'Confirmar Contraseña', 'required|matches[password]');
    
        // reCAPTCHA validation
        $recaptchaResponse = trim($this->input->post('g-recaptcha-response'));
        $userIp = $this->input->ip_address();
        $secret = '6Lfh0v8pAAAAACBl_tc0zYdsZlP6AwOf0PAQ1eNH'; // Tu clave secreta
    
        $recaptchaUrl = 'https://www.google.com/recaptcha/api/siteverify?secret=' . $secret . '&response=' . $recaptchaResponse . '&remoteip=' . $userIp;
        $recaptcha = file_get_contents($recaptchaUrl);
        $recaptcha = json_decode($recaptcha);
    
        if ($this->form_validation->run() == FALSE || !$recaptcha->success) {
            $this->session->set_flashdata('error', 'Por favor completa el formulario correctamente y asegurate de haber realizado el reCAPTCHA.');
            $this->load->view('register');
        } else {
            $data = array(
                'documento_tipo' => $this->input->post('documento_tipo'),
                'documento_numero' => $this->input->post('documento_numero'),
                'nombres' => $this->input->post('nombres'),
                'apellidos' => $this->input->post('apellidos'),
                'correo_electronico' => $this->input->post('correo_electronico'),
                'usuario' => $this->input->post('correo_electronico'), // Usar correo electrónico como nombre de usuario
                'celular' => $this->input->post('celular'),
                
                'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT)
            );
    
            if ($this->Usuario_model->register($data)) {
                redirect('welcome/index');
            } else {
                $this->session->set_flashdata('error', 'Failed to register user');
                redirect('welcome/show_register');
            }
        }
    }
    
    public function check_duplicate_dni($dni) {
        $result = $this->Usuario_model->check_duplicate_dni($dni);
        if ($result) {
            $this->form_validation->set_message('check_duplicate_dni', 'El DNI ya esta registrado.');
            return FALSE;
        }
        return TRUE;
    }
    
    public function check_duplicate_celular($celular) {
        $result = $this->Usuario_model->check_duplicate_celular($celular);
        if ($result) {
            $this->form_validation->set_message('check_duplicate_celular', 'El numero de celular ya esta registrado.');
            return FALSE;
        }
        return TRUE;
    }



    public function perfil() {
        if (!$this->session->userdata('logged_in')) {
            redirect('welcome/index');
        }
    
        $username = $this->session->userdata('username');
        $data['usuario'] = $this->Usuario_model->get_usuario_por_nombre($username);
        $this->load->view('perfil', $data);
    }
    
    public function update_profile() {
        if (!$this->session->userdata('logged_in')) {
            redirect('welcome/index');
        }
    
        $username = $this->session->userdata('username');
        $usuario = $this->Usuario_model->get_usuario_por_nombre($username);
    
        $this->form_validation->set_rules('documento_tipo', 'Documento', 'required');
        $this->form_validation->set_rules('documento_numero', 'Número de documento', 'required');
        $this->form_validation->set_rules('nombres', 'Nombres', 'required');
        $this->form_validation->set_rules('apellidos', 'Apellidos', 'required');
        $this->form_validation->set_rules('correo_electronico', 'Correo electrónico', 'required|valid_email');
        $this->form_validation->set_rules('celular', 'Celular', 'required');
    
        if ($this->form_validation->run() == FALSE) {
            $this->perfil();
        } else {
            $data = array(
                'documento_tipo' => $this->input->post('documento_tipo'),
                'documento_numero' => $this->input->post('documento_numero'),
                'nombres' => $this->input->post('nombres'),
                'apellidos' => $this->input->post('apellidos'),
                'correo_electronico' => $this->input->post('correo_electronico'),
                'celular' => $this->input->post('celular')
            );
    
            if ($this->Usuario_model->actualizar_usuario($usuario->id, $data)) {
                $this->session->set_flashdata('success', 'Perfil actualizado con exito.');
            } else {
                $this->session->set_flashdata('error', 'Hubo un problema al actualizar tu perfil. Por favor, inténtalo de nuevo.');
            }
    
            redirect('welcome/perfil');
        }
    }
    
    public function checkout() {
        $data['cart'] = $this->Cart_model->get_cart();
        $data['total'] = $this->Cart_model->get_total();
        $this->load->view('checkout', $data);
    }




}
