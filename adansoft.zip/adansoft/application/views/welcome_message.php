<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Signin Template �� Bootstrap v5.3</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/sign-in/">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

    <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
      body, html {
            height: 100%;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #E2E0E0;
      }
      .form-signin {
          max-width: 400px;
          padding: 15px;
          margin: auto;
      }
      .form-signin .form-floating:focus-within {
          z-index: 2;
      }
      .form-signin input[type="email"] {
          margin-bottom: -1px;
          border-bottom-right-radius: 0;
          border-bottom-left-radius: 0;
      }
      .form-signin input[type="password"] {
          margin-bottom: 10px;
          border-top-left-radius: 0;
          border-top-right-radius: 0;
      }
      .form-signin .checkbox {
          font-weight: 400;
      }
      .form-signin .btn {
          width: 100%;
      }
      .bg-image {
          background-image: url('https://adan.ed.pe/assets/imagenes/background.jpg'); /* Ruta de tu imagen de fondo */
          background-size: cover;
          background-position: center;
          height: 100%;
          display: flex;
          align-items: center;
      }
      .logo {
          width: 100%;
          max-width: 150px;
          margin-bottom: 20px;
      }
    </style>
  </head>
  <body>
    <div class="bg-image">
      <div class="form-signin text-center bg-light p-4 rounded shadow">
        <img src="https://adan.ed.pe/assets/imagenes/logo_oficial.png" alt="Farmacia Online" class="logo">
        <h1 class="h3 mb-3 fw-normal">Ingreso al Sistema </h1>
        <?php if ($this->session->flashdata('error')): ?>
          <div class="alert alert-danger" role="alert">
              <?php echo $this->session->flashdata('error'); ?>
          </div>
        <?php endif; ?>
        <?php echo form_open("welcome/verificaingreso"); ?>
          <div class="form-floating">
            <input type="email" class="form-control" id="user" name="user" placeholder="tucorreo@gmail.com" required>
            <label for="user">Correo Electronico</label>
          </div>
          <div class="form-floating">
            <input type="password" class="form-control" id="pass" name="pass" placeholder="Password" required>
            <label for="pass">Contrasena</label>
          </div>
          <div class="checkbox mb-3 text-start">
            <label>
              <input type="checkbox" value="remember-me"> Recuerdame
            </label>
          </div>
          <button class="btn btn-primary" type="submit">Ingresar</button>
          <p class="mt-3 mb-3 text-muted">&copy; 2024-2030</p>
        <?php echo form_close(); ?>
        <p>
          <a href="<?php echo site_url('welcome/show_register'); ?>">Crear una cuenta</a>
        </p>
      </div>
    </div>
  </body>
</html>

