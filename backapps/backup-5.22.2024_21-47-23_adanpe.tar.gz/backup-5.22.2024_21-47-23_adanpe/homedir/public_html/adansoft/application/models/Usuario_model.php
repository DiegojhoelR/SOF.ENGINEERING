<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->user_db = $this->load->database('user_db', TRUE); // Cargar la base de datos de usuarios
    }

    public function register($username, $password) {
        $data = array(
            'usuario' => $username,
            'password' => md5($password) // Hasheando la contraseña antes de guardarla
        );
        return $this->user_db->insert('usuarios', $data); // Usar la conexión user_db
    }

    public function login($username, $password) {
        $hashed_password = md5($password);
        $this->user_db->where('usuario', $username);
        $this->user_db->where('password', $hashed_password);
        $query = $this->user_db->get('usuarios'); // Usar la conexión user_db
        
        if ($query->num_rows() == 1) {
            return $query->row();
        } else {
            return false;
        }
    }
}
