<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mi Perfil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            padding-top: 60px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            background: #fff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-check-label {
            display: block;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .header img {
            height: 60px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="header">
            <img src="https://adan.ed.pe/assets/imagenes/logo_oficial.png" alt="Logo">
            <a href="<?php echo site_url('welcome/home'); ?>" class="btn btn-primary">Inicio</a>
        </div>
        <h2 class="text-center">Mi Perfil</h2>
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success">
                <?php echo $this->session->flashdata('success'); ?>
            </div>
        <?php endif; ?>
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('error'); ?>
            </div>
        <?php endif; ?>
        <?php echo form_open('welcome/update_profile'); ?>
            <div class="row">
                <div class="form-group col-md-6">
                    <label for="documento_tipo">Documento</label>
                    <select name="documento_tipo" class="form-control" required>
                        <option value="DNI" <?php echo ($usuario->documento_tipo == 'DNI') ? 'selected' : ''; ?>>DNI</option>
                        <option value="Pasaporte" <?php echo ($usuario->documento_tipo == 'Pasaporte') ? 'selected' : ''; ?>>Pasaporte</option>
                        <option value="Carnet de Extranjer��a" <?php echo ($usuario->documento_tipo == 'Carnet de Extranjer��a') ? 'selected' : ''; ?>>Carnet de Extranjer��a</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    <label for="documento_numero">Numero de documento *</label>
                    <input type="text" name="documento_numero" class="form-control" value="<?php echo $usuario->documento_numero; ?>" required>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    <label for="nombres">Nombres *</label>
                    <input type="text" name="nombres" class="form-control" value="<?php echo $usuario->nombres; ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="apellidos">Apellidos *</label>
                    <input type="text" name="apellidos" class="form-control" value="<?php echo $usuario->apellidos; ?>" required>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    <label for="correo_electronico">Correo electronico *</label>
                    <input type="email" name="correo_electronico" class="form-control" value="<?php echo $usuario->correo_electronico; ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="celular">Celular *</label>
                    <input type="text" name="celular" class="form-control" value="<?php echo $usuario->celular; ?>" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar Perfil</button>
        <?php echo form_close(); ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
