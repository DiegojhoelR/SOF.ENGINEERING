<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Producto_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->user_db = $this->load->database('user_db', TRUE);
    }

    public function get_productos($categoria = null, $keyword = null) {
        if ($categoria) {
            $this->user_db->where('categoria', $categoria);
        }
        if ($keyword) {
            $this->user_db->like('nombre', $keyword);
            $this->user_db->or_like('descripcion', $keyword);
        }
        $query = $this->user_db->get('productos');
        return $query->result();
    }

    public function get_categorias() {
        $this->user_db->select('categoria');
        $this->user_db->distinct();
        $query = $this->user_db->get('productos');
        return $query->result();
    }
    public function update_stock($product_id, $quantity) {
        $this->user_db->set('stock', 'stock-' . $quantity, FALSE);
        $this->user_db->where('id', $product_id);
        $this->user_db->update('productos');
    }

    public function get_stock($product_id) {
        $this->user_db->select('stock');
        $this->user_db->where('id', $product_id);
        $query = $this->user_db->get('productos');
        return $query->row()->stock;
    }
}
