<?php
class Consultas extends CI_Model {

    public function __construct(){
        $this->load->database();
    }

    public function register($username, $password) {
        $data = array(
            'usuario' => $username,
            'password' => md5($password) // Asegúrate de que estás usando el mismo método de encriptación
        );

        return $this->db->insert('usuarios', $data);
    }

    public function login($username, $password) {
        $this->db->where('usuario', $username);
        $this->db->where('password', md5($password)); // Asegúrate de que estás usando el mismo método de encriptación
        $query = $this->db->get('usuarios');

        if ($query->num_rows() == 1) {
            return true;
        } else {
            return false;
        }
    }
}
?>