<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Crear mi cuenta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            padding-top: 60px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            background: #fff;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Crear mi cuenta</h2>
        <p class="text-center">Completa tus datos para que puedas realizar tus compras más rápido.</p>
        <?php if($this->session->flashdata('error')): ?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('error'); ?>
            </div>
        <?php endif; ?>
        <?php echo form_open('welcome/register'); ?>
            <div class="row">
                <div class="form-group col-md-6">
                    <label for="documento_tipo">Documento</label>
                    <select name="documento_tipo" class="form-control" required>
                        <option value="DNI">DNI</option>
                        <option value="Pasaporte">Pasaporte</option>
                        <option value="Carnet de Extranjería">Carnet de Extranjería</option>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    <label for="documento_numero">Número de documento *</label>
                    <input type="text" name="documento_numero" class="form-control" required>
                    <?php echo form_error('documento_numero'); ?>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    <label for="nombres">Nombres *</label>
                    <input type="text" name="nombres" class="form-control" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="apellidos">Apellidos *</label>
                    <input type="text" name="apellidos" class="form-control" required>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    <label for="correo_electronico">Correo electrónico *</label>
                    <input type="email" name="correo_electronico" class="form-control" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="celular">Celular *</label>
                    <input type="text" name="celular" class="form-control" required>
                    <?php echo form_error('celular'); ?>
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-6">
                    <label for="password">Contraseña *</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="conf_password">Confirmar contraseña *</label>
                    <input type="password" name="conf_password" class="form-control" required>
                </div>
            </div>
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="terms" required>
                <label class="form-check-label" for="terms">He leído y acepto los <a href="#">Términos y Condiciones</a> y las <a href="#">Políticas de Privacidad</a>.</label>
            </div>
            <div class="form-group">
                <div class="g-recaptcha" data-sitekey="6Lfh0v8pAAAAAJmPzq-i57OXDLOAEwJxQWix67yJ"></div> <!-- Tu clave de sitio -->
            </div>
            <button type="submit" class="btn btn-primary">Crear mi cuenta</button>
        <?php echo form_close(); ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</body>
</html>
