<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Panel de Usuario</title>
</head>
<body>
    <h1>Bienvenido, <?php echo $this->session->userdata('username'); ?>!</h1>
    <p>Este es tu panel de usuario .</p>
    <a href="<?php echo site_url('welcome/logout'); ?>">Cerrar sesion</a>
</body>
</html>
