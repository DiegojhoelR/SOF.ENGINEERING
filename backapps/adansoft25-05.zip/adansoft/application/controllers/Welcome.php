<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library(array('form_validation', 'session'));
        $this->load->model('Producto_model');
        $this->load->model('Usuario_model'); // Asegúrate de cargar el modelo de usuarios
    }

    public function index() {
        $this->load->view('welcome_message');
    }

    public function home() {
        $data['productos'] = $this->Producto_model->get_productos();
        $this->load->view('home', $data);
    }

     public function verificaingreso() {
        $username = $this->input->post("user");
        $password = $this->input->post("pass");

        // Mensajes de depuración
        log_message('debug', 'Welcome::verificaingreso - username: ' . $username);
        log_message('debug', 'Welcome::verificaingreso - password: ' . $password);

        $resultado = $this->Usuario_model->login($username, $password);
        if ($resultado) {
            $this->session->set_userdata('username', $username);
            $this->session->set_userdata('logged_in', TRUE);
            log_message('debug', 'Welcome::verificaingreso - Sesión iniciada correctamente');
            redirect('welcome/home'); // Redirigir a la página principal si el inicio de sesión es exitoso
        } else {
            log_message('debug', 'Welcome::verificaingreso - Credenciales incorrectas');
            $this->session->set_flashdata('error', 'Correo o contraseña incorrectos');
            redirect('welcome/index'); // Volver a la página de inicio de sesión con el mensaje de error
        }
    }

    public function panel() {
        if (!$this->session->userdata('logged_in')) {
            redirect('welcome/index');
        }
        $this->load->view('panel1');
    }

    public function logout() {
        // Destroy session data
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('logged_in');
        $this->session->sess_destroy();
        redirect('welcome/index');
    }

    public function show_register() {
        $this->load->view('register');
    }

    public function register() {
        // Set form validation rules
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() == FALSE) {
            // Validation failed
            $this->load->view('register');
        } else {
            // Get input values
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            // Register the user
            if ($this->Usuario_model->register($username, $password)) { // Asegúrate de usar el modelo correcto
                echo "User registered successfully";
            } else {
                echo "Failed to register user";
            }
        }
    }
    
}



